/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package jkhahnban;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author kgahlisho
 */
public class JKahnBaneTest {
    
    public JKahnBaneTest() {
    }

    /**
     * Test of run method, of class JKahnBane.
     */
    @Test
    public void testRun() {
        
        
        
        
    }
    
}
